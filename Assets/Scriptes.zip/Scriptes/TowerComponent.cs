﻿using UnityEngine;


public class TowerComponent : MonoBehaviour
{
public int PlayerID;
public int index;

}
